<?php
   // Initialize the session
   session_start();
    
   // Check if the user is already logged in, if yes then redirect him to welcome page
   if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
       header("location: student.php");
       exit;
   }
    
   // Include config file
   require_once "php/config.php";
    
   // Define variables and initialize with empty values
   $email = $password = $fname= "";
   $email_err = $password_err = "";
    
   // Processing form data when form is submitted
   if($_SERVER["REQUEST_METHOD"] == "POST"){
    
       // Check if email is empty
       if(empty(trim($_POST["email"]))){
           $email_err = "Please enter email.";
       } else{
           $email = trim($_POST["email"]);
       }
       
       // Check if password is empty
       if(empty(trim($_POST["password"]))){
           $password_err = "Please enter your password.";
       } else{
           $password = trim($_POST["password"]);
       }
       
       // Validate credentials
       if(empty($email_err) && empty($password_err)){
           // Prepare a select statement
           $sql = "SELECT id, fname, email, password FROM register WHERE email = ?";
           
           if($stmt = mysqli_prepare($link, $sql)){
               // Bind variables to the prepared statement as parameters
               mysqli_stmt_bind_param($stmt, "s", $param_email);
               
               // Set parameters
               $param_email = $email;
               $param_fname = $fname;
               
               // Attempt to execute the prepared statement
               if(mysqli_stmt_execute($stmt)){
                   // Store result
                   mysqli_stmt_store_result($stmt);
                   
                   // Check if email exists, if yes then verify password
                   if(mysqli_stmt_num_rows($stmt) == 1){                    
                       // Bind result variables
                       mysqli_stmt_bind_result($stmt, $id, $fname, $email, $hashed_password);
                       if(mysqli_stmt_fetch($stmt)){
                           if(password_verify($password, $hashed_password)){
                             if($email=="admin@gmail.com" && $password=="admin123"){
                                 session_start();
                               
                               // Store data in session variables
                               $_SESSION["roleID"] = 1;
                               $_SESSION["loggedin"] = true;
                               $_SESSION["id"] = $id;
                               $_SESSION["email"] = $email; 
                               $_SESSION["fname"] = $fname;  
   
                               
                               // Redirect user to welcome page
                               header("location: admin.php");
                            }
                             else{
                               // Password is correct, so start a new session
                               session_start();
                               
                               // Store data in session variables
                               $_SESSION["roleID"] = 2;
                               $_SESSION["loggedin"] = true;
                               $_SESSION["id"] = $id;
                               $_SESSION["email"] = $email;  
                               $_SESSION["fname"] = $fname;                          
                               
                               // Redirect user to welcome page
                               header("location: student.php");
                             }
                           } 
                           else{
                               // Display an error message if password is not valid
                               $password_err = "The password you entered was not valid.";
                           }
                       }
                   } else{
                       // Display an error message if email doesn't exist
                       $email_err = "No account found with that email.";
                   }
               } else{
                   echo "Oops! Something went wrong. Please try again later.";
               }
   
               // Close statement
               mysqli_stmt_close($stmt);
           }
       }
       
       // Close connection
       mysqli_close($link);
   }
   ?>


<!DOCTYPE html>
<html>
   <head>
      <title></title>
   </head>
   <body>
      <!DOCTYPE html>
      <html lang="en">
         <head>
            <?php include('layout/links.php'); ?>
            <style type="text/css">
               .card-login .form {
               min-height: 230px !important;
               }
               .card-login .card-body {
               padding: 13px 30px 0px 10px  !important;
               }
            </style>
         </head>
         <body class="index-page sidebar-collapse">
            <div class="section section-signup page-header" style="background-image: url('../assets/img/city.jpg');height:100vh;">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-4 col-md-6 ml-auto mr-auto">
                        <div class="card card-login">
                           <form class="form"  method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                              <div class="card-header card-header-primary text-center">
                                 <h4 class="card-title">Login Form</h4>
                              </div>
                              <div class="card-body">
                                 <div class="form-group d-flex <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                                    <div class="input-group-prepend mr-2">
                                       <span class="input-group-text">
                                       <i class="material-icons">mail</i>
                                       </span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Email..." name="email" value="<?php echo $email; ?>">
                                    <span class="help-block"><?php echo $email_err; ?></span>
                                 </div>
                                 <div class="form-group d-flex <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                                    <div class="input-group-prepend mr-2">
                                       <span class="input-group-text">
                                       <i class="material-icons">lock_outline</i>
                                       </span>
                                    </div>
                                    <input type="password" class="form-control" placeholder="Password..." name="password">
                                    <span class="help-block"><?php echo $password_err; ?></span>
                                 </div>
                              </div>
                              <div class="footer text-center">
                                 <a href="reg.php" class="btn btn-primary btn-link btn-wd btn-sm">Register</a>
                                 <input type="submit" name="login" class="btn btn-primary btn-sm" value="Login">
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </body>
      </html>