function deleteEvent(id){
    if(confirm("Are You sure?")){
       $.ajax({
          type: 'post',
          url:'php/delete.php',
          data:{delete_id:id},
          success:function(data){
             $('#delete'+id).hide('slow');
          }
       });
    }
 }

function deleteJob(id){
    if(confirm("Are You sure?")){
       $.ajax({
          type: 'post',
          url:'php/deleteJob.php',
          data:{delete_id:id},
          success:function(data){
             $('#delete'+id).hide('slow');
          }
       });
    }
 }

  function deleteRegister(id){
    if(confirm("Are You sure?")){
       $.ajax({
          type: 'post',
          url:'php/deleteRegister.php',
          data:{delete_id:id},
          success:function(data){
             $('#delete'+id).hide('slow');
          }
       });
    }
 }

 // photo
  $('#insert').click(function(){
   var image_name = $('#image').val();
   if(image_name == ''){
      alert("Pelese Select Image");
      return false;
   }
   else{
      var extension = $('#image').val().split('.').pop().toLowerCase();
      if(jQuery.inArray(extension, ['gif', 'png', 'jpg','jpeg']) == -1){
         alert('Invalid Image File');
         $('#image').val('');
         return false;
      }
   }
});

  
$(document).ready(function(){

   //admin Search
    load_data();

    function load_data(query)
    {
     $.ajax({
      url:"php/fetch.php",
      method:"POST",
      data:{query:query},
      success:function(data)
      {
       $('#result').html(data);
      }
     });
    }
    $('#search_text').keyup(function(){
     var search = $(this).val();
     if(search != '')
     {
      load_data(search);
     }
     else
     {
      load_data();
     }
    });

//student search



    //  Image Modal
     $(function() {
         $('.pop').on('click', function() {
            $('.imagepreview').attr('src', $(this).find('img').attr('src'));
            $('#imagemodal').modal('show');   
         });      
   });


     // recipeCarousel
      $('#recipeCarousel').carousel({
      interval: 10000
      })
      
      $('.carousel .carousel-item').each(function(){
      var minPerSlide = 4;
      var next = $(this).next();
      if (!next.length) {
      next = $(this).siblings(':first');
      }
      next.children(':first-child').clone().appendTo($(this));
      
      for (var i=0;i<minPerSlide;i++) {
      next=next.next();
      if (!next.length) {
        next = $(this).siblings(':first');
      }
      
      next.children(':first-child').clone().appendTo($(this));
      }
      });

      // Validation



       function validation(){
         var form_fname = document.getElementById('form_fname').value;
         var form_lname = document.getElementById('form_lname').value;
         var form_email = document.getElementById('form_email').value;
         var form_phone = document.getElementById('form_phone').value;
         var form_password = document.getElementById('form_password').value;
         var form_retype_password = document.getElementById('form_retype_password').value;

         if(form_fname == ""){
            document.getElementById('fname').innerHTML="** Please fill the first name**";
            return false;
         }

         if((form_fname.length <=2) || (form_fname.length >20)){
            document.getElementById('fname').innerHTML="** Please fill the first name**";
            return false;
         }
         if(!isNaN(form_fname)){
            document.getElementById('fname').innerHTML = "** Only characters are allowed**";
            return false;
         }  

         
         if(form_lname == ""){
            document.getElementById('lname').innerHTML="** Please fill the last name**";
            return false;
         }
          if((form_lname.length <=2) || (form_lname.length >20)){
            document.getElementById('lname').innerHTML="** Please fill the first name**";
            return false;
         }
         if(!isNaN(form_lname)){
            document.getElementById('lname').innerHTML = "** Only characters are allowed**";
            return false;
         }  


          if(form_phone == ""){
            document.getElementById('phone').innerHTML="** Please fill the contact **";
            return false;
         }
         if(isNaN(form_phone)){
            document.getElementById('phone').innerHTML="** User must write digits only not characters **";
            return false;
         }

         if(form_phone.length != 10){
            document.getElementById('phone').innerHTML="** Mobile number must be 10 digits **";
            return false;
         }

         if(form_email == ""){
            document.getElementById('email').innerHTML="** Please fill the email**";
            return false;
         }
         if(form_email.indexOf('@') <= 0){
            document.getElementById('email').innerHTML="** @ Invalid position**";
            return false;
         }
         if((form_email.charAt(form_email.length-4) !='.')&&(form_email.charAt(form_email.length-3) !='.')){
            document.getElementById('email').innerHTML="** Invalid email**";
            return false;
         }



         if(form_password == ""){
            document.getElementById('password').innerHTML="** Enter a Password **";
            return false;
         }
          if(form_retype_password == ""){
            document.getElementById('retype_password').innerHTML="** fill the password field **";
            return false;
         }


          if((form_password.length <=5) || (form_password.length >20)){
            document.getElementById('password').innerHTML="** Password length must be between 5 to 8**";
            return false;
         }

         if(form_password !== form_retype_password){
            document.getElementById('password').innerHTML="** Passwords are not matching**";
           document.getElementById('retype_password').innerHTML="** Passwords are not matching**";

            return false;
         }

        
      }



      // Delete recoed from database
      
      // function deleteEvent(id){
      //        if(confirm("Are You sure?")){
      //           $.ajax({
      //              type: 'post',
      //              url:'delete.php',
      //              data:{delete_id:id},
      //              success:function(data){
      //                 $('#delete'+id).hide('slow');
      //              }
      //           });
      //        }
      //     }

     

 

           //Page ID

      function ContentPage(id){
      location.href = "reg.php?id="+id;
   }


});
    

   