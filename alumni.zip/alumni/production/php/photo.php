 
 <?php
include('connection.php');
if(isset($_POST["insert"])){
   $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
   $query = "INSERT INTO tbl_image(name) VALUES ('$file')";
   if(mysqli_query($conn, $query)){
      echo '<script> alert("Image Inserted into Database")</script>';
      header("Location:../admin.php");
   }
}

?>