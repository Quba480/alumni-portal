<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "pro");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM register 
  WHERE fname LIKE '%".$search."%'
  OR email LIKE '%".$search."%' 
  OR enrollment LIKE '%".$search."%' 
 ";
}
else
{
 $query = "
  SELECT * FROM register ORDER BY id
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table-hover table-bordered table-condensed">
    <tr>
     <th>Name</th>
     <th>email</th>
     <th>contact</th>
     <th>year</th>
     <th>Profession</th>
     <th>Action</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["fname"]." ".$row["lname"].'</td>
    <td>'.$row["email"].'</td>
    <td>'.$row["contact"].'</td>
    <td>'.$row["year"].'</td>
    <td>'.$row["empname"].'</td>
    <td><i class="fa fa-eye mr-2" style="color: #00bcd4" title="View" aria-hidden="true"></i>
</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>