<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pro";

$conn = mysqli_connect($servername,$username,$password,$dbname);



$jobTitle = $_POST['jobTitle'];
$companyName = $_POST['companyName'];
$duration = $_POST['duration'];
$salary = $_POST['salary'];
$ApplyBy = $_POST['ApplyBy'];

  $insertquery="insert into job(jobTitle, companyName, duration, salary, ApplyBy) values('$jobTitle', '$companyName', '$duration', '$salary','$ApplyBy')";

  if(mysqli_query($conn, $insertquery)){
      header('location:../admin.php');  
}
else{
  echo "error: could not able to execute $insertquery. ";
  mysqli_error($conn);
  header('location:admin.php');  

}



?>



