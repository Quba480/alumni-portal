<?php 
$servername = "localhost";
                              $username = "root";
                              $password = "";
                              $dbname = "pro";
                           
                              $conn = mysqli_connect($servername,$username,$password,$dbname);
$id = $_POST['delete_id'];
$query = mysqli_query($conn,"DELETE from job WHERE id='$id'");
?>