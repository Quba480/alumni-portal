<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "pro");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM register 
  WHERE fname LIKE '%".$search."%'
  OR email LIKE '%".$search."%' 
  OR enrollment LIKE '%".$search."%' 
 ";
}
else
{
 $query = "
  SELECT * FROM register ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
  
  <div class="col-md-3">
                     <div class="card">
                        <div class="card-body p-10">
                           <div class="profile-photo-small search-profile" >
                              <img src="assets-pro/images/pic.jpg" alt="Circle Image" class="rounded-circle img-fluid mb-2">
                           </div>
                           <h4 class="card-title">Name: '.$row["fname"]." ".$row["lname"].' </h4>
                           <!-- <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6> -->
                           <span class="card-text">Class of '.$row["year"].'</span><br>
                           <span class="card-text">'.$row["degree"].'</span><br>
                           <span class="card-text">'.$row["location"].'</span><br>
                           <a href="javascript:;" class="btn btn-xs btn-outline card-link float-right">View profile</a>
                           <!--  <a href="javascript:;" class="card-link">Another link</a> -->
                        </div>
                     </div>
                  </div>
              
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>