<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pro";

$conn = mysqli_connect($servername,$username,$password,$dbname);



$title = $_POST['title'];
$date = $_POST['date'];
$startTime = $_POST['startTime'];
$endTime = $_POST['endTime'];
$location = $_POST['location'];


  $insertquery="insert into event(title, date, startTime, endTime, location) values('$title', '$date', '$startTime', '$endTime','$location')";


// if(mysqli_query($conn, $insertquery)){
// 	echo "records added successfully.";
// }
// else{
// 	echo "error: could not able to execute $insertquery. ";
// 	mysqli_error($conn);
// }

  if(mysqli_query($conn, $insertquery)){
      header('location:../admin.php');  
}
else{
  echo "error: could not able to execute $insertquery. ";
  mysqli_error($conn);
  header('location:../admin.php');  
}




?>



