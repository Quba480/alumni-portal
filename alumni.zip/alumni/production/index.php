<?php include('layout/onePageHeader.php'); ?>
 <div class="container-fluid">
      <div class="card">
      <div class="row">
         <div class="col-md-12">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="height:400px;">
               <ol class="carousel-indicators">
                  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
               </ol>
               <div class="carousel-inner" style="height:384px;">
                  <div class="carousel-item active">
                     <img src="assets-pro/images/slide_1.jpeg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="assets-pro/images/slide_2.jpeg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="assets-pro/images/slide_3.jpeg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="assets-pro/images/slide_4.jpeg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                     <img src="assets-pro/images/slide_5.jpeg" class="d-block w-100" alt="...">
                  </div>
               </div>
               <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
               <span class="carousel-control-prev-icon" aria-hidden="true"></span>
               <span class="sr-only">Previous</span>
               </a>
               <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
               <span class="carousel-control-next-icon" aria-hidden="true"></span>
               <span class="sr-only">Next</span>
               </a>
            </div>
         </div>
      </div>
      <div class="row" id="about" style="padding: 0 2%;">
         <div class="col-md-12 mx-auto text-center">
            <h2 class="title">The Alumni Portal</h2>
            <hr style="width: 30%;">
         </div>
         <div class="col-md-6">
            <h4 class="text-justify">It is a web-based application that helps:</h4>
            <ul>
               <li>
                  Collect up-to-date data about alumni.
               </li>
               <li>
                  Organize it in a way that it can be searched department-wise, industry wise, location wise, skill-wise, simple keywords search, or a combination of these.
               </li>
               <li>
                  Lets alumni network amongst themselves.
               </li>
               <li>
                  Lets administrators or alumni post various content-News, Events, Blogpost, Picture, Videos, etc
               </li>
               <li>
                  It allow posting of jobs and lets alumni apply on jobs.
               </li>
            </ul>
         </div>
         <div class="col-md-6 text-center">
            <img src="assets-pro/images/social.jpg" rel="nofollow" alt="Card image cap">
         </div>
      </div>
      <div class="row" id="programmes" style="padding: 0 2%;">
         <div class="col-md-12 mx-auto text-center">
            <h2 class="title">ONLINE PROGRAMMES</h2>
            <hr style="width: 30%;">
         </div>
         <div class="col-md-6">
            <ul class="list-group">
               <li class="list-group-item">
                  <span style="width: 72%">Advertising Management and Public Relations</span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%">Market Research and Data Analytics</span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%">Digital Marketing and Communication with Specialisations </span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%"> Digital Marketing </span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
            </ul>
         </div>
         <div class="col-md-6">
            <ul class="list-group">
               <li class="list-group-item">
                  <span style="width: 72%">Media and Entertainment Management</span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%">Business Management </span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%">Sales and Marketing Communication </span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
               <li class="list-group-item">
                  <span style="width: 72%"> Digital Marketing </span>
                  <span class="float-right"><a class="badge badge-pill badge-warning" href="">Apply Online</a></span>
               </li>
            </ul>
         </div>
      </div>
      <div class="row mx-auto my-auto" style="padding: 0 2%;">
         <div class="col-md-12 mx-auto text-center">
            <h2 class="title">FEATURED ALUMNI</h2>
            <hr style="width: 30%;">
         </div>
         <div id="recipeCarousel" class="carousel slide w-100" data-ride="carousel">
            <div class="carousel-inner smallSlider" role="listbox">
               <div class="carousel-item active">
                  <div class="col-md-3">
                     <div class="card">
                        <div class="card-body p-10">
                           <div class="profile-photo-small search-profile" >
                              <img src="assets-pro/images/avatar.jpg" alt="Circle Image" class="rounded-circle img-fluid mb-2">
                           </div>
                           <h4 class="card-title">1Asdesh Gajanan Magare</h4>
                           <span class="card-text">Present Status</span><br>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="col-md-3">
                     <div class="card">
                        <div class="card-body p-10">
                           <div class="profile-photo-small search-profile" >
                              <img src="assets-pro/images/avatar.jpg" alt="Circle Image" class="rounded-circle img-fluid mb-2">
                           </div>
                           <h4 class="card-title">2Asdesh Gajanan Magare</h4>
                           <span class="card-text">Present Status</span><br>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="col-md-3">
                     <div class="card">
                        <div class="card-body p-10">
                           <div class="profile-photo-small search-profile" >
                              <img src="assets-pro/images/avatar.jpg" alt="Circle Image" class="rounded-circle img-fluid mb-2">
                           </div>
                           <h4 class="card-title">3Asdesh Gajanan Magare</h4>
                           <span class="card-text">Present Status</span><br>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="col-md-3">
                     <div class="card">
                        <div class="card-body p-10">
                           <div class="profile-photo-small search-profile" >
                              <img src="assets-pro/images/avatar.jpg" alt="Circle Image" class="rounded-circle img-fluid mb-2">
                           </div>
                           <h4 class="card-title">4Asdesh Gajanan Magare</h4>
                           <span class="card-text">Present Status</span><br>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev w-auto" href="#recipeCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next w-auto" href="#recipeCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
         </div>
      </div>
      <div class="row" style="padding: 0 2%;" id="contact">
         <div class="card">
            <div class="col-md-12 mx-auto text-center">
               <h2 class="title">Get in Touch with us</h2>
               <hr style="width: 30%;">
            </div>
            <div class="col-md-12">
               <form class="d-flex mb-4">
                  <div class="col-md-6" style="border-right: 1px solid #ddd">
                     <div class="form-group">
                        <label class="text-left">Your name</label>
                        <div class="input-group ml-0 w-100">
                           <input type="email" class="form-control">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="text-left">Email Address</label>
                        <div class="input-group ml-0 w-100">
                           <input type="email" class="form-control">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="text-left">Mobile No.</label>
                        <div class="input-group ml-0 w-100">
                           <input type="email" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label class="text-left">Message</label>
                        <div class="input-group ml-0 w-100">
                           <textarea class="form-control" rows="6"></textarea>
                        </div>
                     </div>
                     <div>
                        <button type="button" class="btn btn-warning submit" style="float: right"><i class="fa fa-paper-plane" aria-hidden="true"></i>  Send Message</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="row" id="donation" style="padding: 0 2%;">
         <div class="card text-white bg-primary mb-3" style="padding: 15px 0;">
            <div class="col-md-12 d-flex">
               <div class="text-center mt-2" style="width: 90%">
                  <span style="font-size: 18px">“Since you get more joy out of giving joy to others, you should put a good deal of thought into the happiness that you are able to give.” ―Eleanor Roosevelt</span><br>
               </div>
               <div class="text-center mt-2" style="width: 10%">
                  <button class="btn btn-md btn-warning class="btn btn-primary data-toggle="modal" data-target="#exampleModal"><span><i class="fa fa-inr mr-2" aria-hidden="true"></i>Donate</span></button>
               </div>
            </div>
         </div>
      </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Donation Form</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <form>
                <div class="modal-body">
                  <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label>Name</label>
                          <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                          <label>Email</label>
                          <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                          <label>Contact Number</label>
                          <input type="text" class="form-control">
                        </div>
                      </div> 
                      <div class="col-md-6">
                        <div class="form-group">
                          <label>Credit Card Number</label>
                          <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                          <label>Expiration Date</label>
                          <input type="text" class="form-control">
                        </div>
                        <div class="form-group">
                          <label>CVV Number</label>
                          <input type="text" class="form-control">
                        </div>
                      </div> 
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Donate</button>
                </div>
              </form>
            </div>
          </div>
        </div>
     
  
</div>
</div>
 <?php include('layout/footer.php'); ?>
   