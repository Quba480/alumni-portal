<?php
require 'PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';

$servername	= "localhost";
$username = "root";
$password="";
$dbname="pro";

if(isset($_POST['upload'])){
	$inputfilename = $_FILES['file']['tmp_name'];
	$exceldata = array();

	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if(!$conn){
		die("Connection failed".mysqli_connect_error());
	}

	try{
		$inputfiletype = PHPExcel_IOFactory::identify($inputfilename);
		$objReader = PHPExcel_IOFactory::createReader($inputfiletype);
		$objPHPExcel = $objReader->load($inputfilename);
	}
	catch(Exception $e){
		die('Error loading file"'.pathinfo($inputfilename,PATHINFO_BASENAME).'": '.$e->getMessage());
	}
	$sheet =$objPHPExcel->getSheet(0);
	$highestRow = $sheet->getHighestRow();
	$getHightestColumn = $sheet->getHighestColumn();

	for($row =1; $row<= $highestRow; $row++){
		$rowData = $sheet->rangeToArray('A'.$row.':'.$getHightestColumn.$row,NULL,TRUE,FALSE);

		$sql = "INSERT INTO excel(firstname,lastname,email) VALUES ('".$rowData[0][0]."','".$rowData[0][1]."','".$rowData[0][2]."')";

		if (mysqli_query($conn, $sql)) {
			$exceldata[] = $rowData[0];
		}
		else{
			echo "Errors".$sql."<br>".mysqli_error($conn);
		}
		
	}

	echo "<table border='1'>";
	foreach ($exceldata as $index => $excelraw) 
	{
		echo "<tr>";
	
		foreach ($excelraw as $excelcolumn) 
		{
		echo "<td>".$excelcolumn."</td>";
		}
	echo "</tr>";
	}
echo "</table>";
mysqli_close($conn);
}
?>
