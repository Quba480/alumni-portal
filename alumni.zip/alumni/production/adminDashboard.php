<!-- <?php

// Initialize the session
session_start();
 // echo $_SESSION['fname'];
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<?php include('layout/header.php'); ?>
<div class="container-fluid">
   <div class="card">
      <div class="row">
         <div class="col-md-12">
            
            <ul class="nav nav-pills nav-pills-rose d-flex flex-row justify-content-around" role="tablist">
               <li class="nav-item"><a class="nav-link active" href="#pill1" data-toggle="tab">Search Alumni</a></li>
               <li class="nav-item"><a class="nav-link" href="#pill2" data-toggle="tab">Registered Alumni</a></li>
               <li class="nav-item"><a class="nav-link" href="#pill3" data-toggle="tab">Add New Bactch</a></li>
               <li class="nav-item"><a class="nav-link" href="#pill4" data-toggle="tab">Job Post</a></li>
               <li class="nav-item"><a class="nav-link" href="#pill5" data-toggle="tab">Events Post</a></li>
               <li class="nav-item"><a class="nav-link" href="#pill6" data-toggle="tab">Photo Gallery</a></li>
            </ul>
         </div>
      </div>
      <div class="tab-content tab-space">
         <div class="tab-pane active" id="pill1">
            <div class="row cardDataPadd">
               <div class="col-md-2"></div>
               <div class="col-md-8">
                     <div class="input-group sc mb-4">
                        <input type="text" name="search_text" id="search_text" class="form-control h-35" placeholder="Search Alumni">
                        <div class="input-group-append">
                           <i class="fa fa-search"></i>
                        </div>
                     </div>
               </div>
               <div class="col-md-12">
                  <div id="result"></div>
               </div> 
            </div>
         </div>
         <div class="tab-pane" id="pill2">
            <div class="row cardDataPadd">
               <div class="col-md-12">
                  <table class="table table-hover table-bordered table-condensed">
                     <thead>
                        <tr>
                           <th>Id</th>
                           <th>Name</th>
                           <th>Email</th>
                           <th>Degree</th>
                           <th>Contact</th>
                           <th class="text-center">Action
                              <a href="reg.php">
                              <i class="fa fa-plus" style="color: #9c27b0" title="Add"></i>
                              </a>
                           </th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           $servername = "localhost";
                              $username = "root";
                              $password = "";
                              $dbname = "pro";
                           
                              $conn = mysqli_connect($servername,$username,$password,$dbname);
                                       $selectquery = "SELECT id,fname,lname,email,degree,contact FROM register";
                                       
                           
                                                $query = mysqli_query($conn, $selectquery);
                           
                              while($result = mysqli_fetch_array($query)){
                                 
                           ?>
                        <tr>
                        <tr id="delete<?php echo $result['id'] ?>">
                           <td><?php echo $result['id']; ?></td>
                           <td><?php echo $result['fname']; ?>&nbsp;<?php echo $result['lname']; ?></td>
                           <td><?php echo $result['email']; ?></td>
                           <td><?php echo $result['degree']; ?></td>
                           <td><?php echo $result['contact']; ?></td>
                           <td class="text-center">
                              <i onclick="ContentPage(<?php echo $result['id'];  ?>)" class="fa fa-eye mr-2" style="color: #00bcd4" title="View" aria-hidden="true"></i>
                              <i onclick="deleteRegister(<?php echo $result['id'];  ?>)" class="fa fa-trash-o" style="color: #f44336" title="Delete" aria-hidden="true"></i>
                           </td>
                        </tr>
                        <?php
                           }
                              ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="tab-pane" id="pill3">
             <div class="container">
               <div class="row cardDataPadd">
                  <div class="col-md-12">
                       <div class="col-md-12 text-center">

                     <form method="post" action="php/addBatch.php" enctype="multipart/form-data">
                     <button type="button" class="btn btn-default"> <span class="m-3">Add new batch</span>
                        <input type="file" name="file" />
                        <input type="submit" name="upload" value="upload">
                     </button> 
                     <hr>
               </form>
            </div>
                      
                     <table class="table table-hover table-bordered table-condensed">
                        <thead>
                           <tr>
                              <th>Id</th>
                              <th>Name</th>
                              <th>Enrollment Number</th>
                              <th>Action</th>

                           </tr>
                        </thead>
                        <tbody>
                           <?php
                           include('php/connection.php');
                                        $selectquery = "SELECT * FROM excel";
                                        
                            
                                                 $query = mysqli_query($conn, $selectquery);
                            
                               while($result = mysqli_fetch_array($query)){
                                  
                            ?>
                           <tr id="delete<?php echo $result['id'] ?>">
                              <td><?php echo $result['id']; ?></td>
                              <td><?php echo $result['firstname']; ?>&nbsp;<?php echo $result['lastname']; ?></td>
                              <td><?php echo $result['enrollment']; ?></td>
                              <td class="text-center">
                                 <i class="fa fa-eye mr-2" style="color: #00bcd4" title="Edit" aria-hidden="true"></i>
                                 <i onclick="deleteJob(<?php echo $result['id'];  ?>)" class="fa fa-trash-o" style="color: #f44336" title="Delete" aria-hidden="true"></i>
                              </td>
                           </tr>
                           <?php
                              }
                                 ?>
                        </tbody>
                     </table>
                  </div>
               </div>
              
            </div>
            <!-- <div class="row">
               <form action="php/addBatch.php" method="POST" enctype="multipart/form-data">
                  <input type="file" name="file">
                  <input type="submit" name="upload" value="upload">
               </form>
            </div> -->
         </div>
         <div class="tab-pane" id="pill4">
            <div class="container">
               <div class="row cardDataPadd">
                  <div class="col-md-12">
                     <table class="table table-hover table-bordered table-condensed">
                        <thead>
                           <tr>
                              <th>Id</th>
                              <th>Job Title</th>
                              <th>Company Name</th>
                              <th>Duration</th>
                              <th>Salary</th>
                              <th>Apply By</th>
                              <th class="text-center">Action
                                 <a data-toggle="modal" data-target="#jobpost">
                                 <i class="fa fa-plus" style="color: #9c27b0" title="Add"></i>
                                 </a>
                              </th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                           include('php/connection.php');
                                        $selectquery = "SELECT id,jobTitle,companyName,duration,salary,ApplyBy FROM job";
                                        
                            
                                                 $query = mysqli_query($conn, $selectquery);
                            
                               while($result = mysqli_fetch_array($query)){
                                  
                            ?>
                           <tr id="delete<?php echo $result['id'] ?>">
                              <td><?php echo $result['id']; ?></td>
                              <td><?php echo $result['jobTitle']; ?></td>
                              <td><?php echo $result['companyName']; ?></td>
                              <td><?php echo $result['duration']; ?></td>
                              <td><?php echo $result['salary']; ?></td>
                              <td><?php echo $result['ApplyBy']; ?></td>
                              <td class="text-center">
                                 <i class="fa fa-eye mr-2" style="color: #00bcd4" title="Edit" aria-hidden="true"></i>
                                 <i onclick="deleteJob(<?php echo $result['id'];  ?>)" class="fa fa-trash-o" style="color: #f44336" title="Delete" aria-hidden="true"></i>
                              </td>
                           </tr>
                           <?php
                              }
                                 ?>
                        </tbody>
                     </table>
                  </div>
               </div>
              
            </div>
         </div>
         <div class="tab-pane" id="pill5">
            <div class="container">
               <div class="row cardDataPadd">
                  <div class="col-md-12">
                     <table class="table table-hover table-bordered table-condensed">
                        <thead>
                           <tr>
                              <th>Id</th>
                              <th>Title</th>
                              <th>Date</th>
                              <th>Start Time</th>
                              <th>End Time</th>
                              <th>Location</th>
                              <th class="text-center">Action
                                 <a data-toggle="modal" data-target="#eventpost">
                                 <i class="fa fa-plus" style="color: #9c27b0" title="Add"></i>
                                 </a>
                              </th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              include('php/connection.php');
                                           $selectquery = "SELECT id,title,date,startTime,endTime,location FROM event";
                                           
                               
                                                    $query = mysqli_query($conn, $selectquery);
                               
                                  while($result = mysqli_fetch_array($query)){
                                     
                               ?>
                           <tr id="delete<?php echo $result['id'] ?>">
                              <td><?php echo $result['id']; ?></td>
                              <td><?php echo $result['title']; ?></td>
                              <td><?php echo $result['date']; ?></td>
                              <td><?php echo $result['startTime']; ?></td>
                              <td><?php echo $result['endTime']; ?></td>
                              <td><?php echo $result['location']; ?></td>
                              <td class="text-center">
                                 <i class="fa fa-eye mr-2" style="color: #00bcd4" title="Edit" aria-hidden="true"></i>
                                 <i onclick="deleteEvent(<?php echo $result['id'];  ?>)" class="fa fa-trash-o" style="color: #f44336" title="Delete" aria-hidden="true"></i>
                              </td>
                           </tr>
                           <?php
                              }
                                 ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               
            </div>
         </div>
         <div class="tab-pane" id="pill6">
            <div class="row" style="padding: 0 2%;">
               <div class="col-md-12 text-center">
               <form method="post" action="php/photo.php" enctype="multipart/form-data">
                     <button type="button" class="btn btn-default"> <span class="m-3">Add photo</span><input type="file" name="image" id="image" />
                        <input type="submit" name="insert" id="insert"  value="Insert">
                     </button> 
                     <hr>
               </form>
                  </div>
               
                  <?php
                     $query = "SELECT * FROM tbl_image ORDER BY id DESC";
                     $result = mysqli_query($conn, $query);
                     while($row = mysqli_fetch_array($result)){
                        echo'
                        <div class="col-md-2 img-outer mx-5 mb-3 cursor-pointer">
                           <!--<i class="fa fa-times" aria-hidden="true" style="float:right;"></i>-->
                           <a data-toggle="modal" data-target="#imageModal" class="pop">
                              <img  id="myImg" src="data:image/jpeg;base64,'.base64_encode($row['name']).'" alt="Rounded Image" class=" img-raised rounded img-fluid f-w" />
                           </a>
                        </div>
                        '; 
                     }
                     ?>
                   
            </div>
         </div>
      </div>
   </div>
</div>

 <div class="modal fade" id="jobpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Job Post Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <form class="form" method="POST" action="php/job.php">
            <div class="modal-body">
               <div class="row" id="job">
                  <div class="col-md-12 m-auto">
                     <div class="card-login">
                        <div class="input-group">
                           <span class="input-group-text">Job Title:</span>     
                           <input type="text" class="form-control" name="jobTitle" >
                        </div>
                        <div class="input-group">
                           <span class="input-group-text">Company Name:</span>     
                           <input type="text" class="form-control" name="companyName">
                        </div>
                        <div class="input-group">
                           <span class="input-group-text">Duration:</span>     
                           <input type="text" class="form-control" name="duration">
                        </div>
                        <div class="input-group">
                           <span class="input-group-text">Salary:</span>     
                           <input type="text" class="form-control" name="salary">
                        </div>
                        <div class="input-group">
                           <span class="input-group-text">Apply By:</span>     
                           <input type="date" class="form-control" name="ApplyBy">
                        </div>
                        <div class="d-flex fr-2">
                           <div class="footer text-center">
                              <a href="studentDashboard.php" class="btn btn-primary btn-link btn-wd btn-lg">View all jobs</a>
                           </div>
                           <div class="footer text-center">
                              <button type="submit" class="btn btn-primary ">
                              Post
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>

<div class="modal fade" id="eventpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
   <div class="modal-content">
      <div class="modal-header">
         <h5 class="modal-title" id="exampleModalLabel">Event Post Form</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">&times;</span>
         </button>
      </div>
      <form class="form" method="POST" action="php/events.php">
         <div class="modal-body">
            <div class="row" id="del">
               <!-- delete function id -->
               <div class="col-md-12 m-auto">
                  <div class="card-login">
                     <div class="input-group">
                        <span class="input-group-text">Title:</span>     
                        <input type="text" class="form-control" name="title">
                     </div>
                     <div class="input-group">
                        <span class="input-group-text">Date:</span>
                        <input type="date" class="form-control" name="date">
                     </div>
                     <div class="input-group">
                        <span class="input-group-text">Start time:</span>
                        <input type="time" class="form-control" name="startTime">
                     </div>
                     <div class="input-group">
                        <span class="input-group-text">End time:</span>
                        <input type="time" class="form-control md-36" name="endTime">
                     </div>
                     <div class="input-group">
                        <span class="input-group-text">Location:</span>
                        <input type="text" class="form-control" name="location">
                     </div>
                  </div>
                  <div class="d-flex ">
                     <div class="footer text-center">
                        <a href="studentDashboard.php" class="btn btn-primary btn-link btn-wd btn-lg">View all events</a>
                     </div>
                     <div class="footer text-center">
                        <button type="submit" class="btn btn-primary btn-round">
                        Post
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </form>
   </div>
</div>
</div>


<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog  modal-md" role="document">
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
         <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
                <img src="" class="imagepreview" style="width: 100%;" >
              <div id="caption"></div>
            </div>
         </div>
         </div>
       </div>
     </div>
   </div>



<?php include('layout/footer.php'); ?>
 -->