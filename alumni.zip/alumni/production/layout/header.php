<!DOCTYPE html>
<html>
   <head>
      <!-- Required meta tags -->
     <?php include('layout/links.php'); ?>
   </head>
      <body>
      <nav class="navbar navbar-default navbar-expand-lg mb-0 bg-light navbar-fixed-top " role="navigation-demo" style="padding: 5px 50px;">
         <!-- Brand and toggle get grouped for better mobile display -->
         <a class="navbar-brand" href="index.php">
            <div class="logo-image">
               <img src="assets-pro/images/logo.jpg" class="img-fluid">
            </div>
         </a>
         <div class="collapse navbar-collapse">
        
            <ul  class="navbar-nav ml-auto">
               <li class="nav-item">
                  <a href="index.php" class="nav-link">
                  Back to Home Page
                  </a>
               </li>
                  <li class="nav-item">
                   <?php 
                   if($_SESSION['roleID'] == 1)
                   {
                  ?>
                     <a href="admin.php" class="nav-link">Admin Dashboard</a>
                  <?php  
                   }
                  ?>
               </li>


               <li class="nav-item">
                  <?php if($_SESSION['roleID'] == 2)
                   {
                  ?>
                     <a href="student.php" class="nav-link">Student Dashboard</a>
                  <?php  
                   }
                  ?>
                  
               </li>
                  <li class="dropdown nav-item">
                     <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                     <i class="fa fa-user"></i> 
                        Profile
                     </a>
                     <div class="dropdown-menu dropdown-with-icons">
                        
                        <a href="#" class="dropdown-item" style="text-transform: uppercase">
                        <?php echo $_SESSION['fname'];?>
                        </a>
                        <a href="reset-password.php" class="dropdown-item">
                        Change Password
                        </a>
                        <a href="logout.php" class="dropdown-item">
                        <i class="fa fa-power-off mr-2"></i> Logout
                        </a>
                     </div>
                  </li>
            </ul>


            

            
            

               <!-- <li><a href="logout.php" class="btn btn-danger">Logout</a></li> -->
           



   </div>
</nav>

