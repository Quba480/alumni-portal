<!DOCTYPE html>
<html>
   <head>
      <?php include('layout/links.php'); ?>
   </head>
   <body>
      <nav class="navbar navbar-default navbar-expand-lg mb-0 bg-light navbar-fixed-top" role="navigation-demo" style="padding: 5px 50px;">
         <a class="navbar-brand" href="index.php">
            <div class="logo-image">
               <img src="assets-pro/images/logo.jpg" class="img-fluid">
            </div>
         </a>
         <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
               <li class="nav-item">
                  <a href="index.php" class="nav-link">
                  Home
                  </a>
               </li>
               <li class="nav-item">
                  <a href="#about" class="nav-link">
                  About Us
                  </a>
               </li>
               <li class="nav-item">
                  <a href="#contact" class="nav-link">
                  Contact Us
                  </a>
               </li>
               <li class="nav-item">
                  <a href="#donation" class="nav-link">
                  Donation
                  </a>
               </li>
               <li class="nav-item">
                  <a href="#programmes" class="nav-link">
                  Online Programmes
                  </a>
               </li>
               
               <li class="nav-item">
                  <a href="login.php"> <span class="btn btn-primary btn-sm">Login</span></a>
               </li>
            </ul>
         </div>
      </nav>