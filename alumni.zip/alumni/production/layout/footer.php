</script>
</body>
<footer>
  <div class="foo">©2020 Copyright: All Rights Reserved. <a href="index.php" style="color: #ff9800">Alumni Portal</a></div>
</footer>
</html>

<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
<script src="../assets/js/plugins/moment.min.js"></script>
<!--  Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
<!-- <script src="../assets/js/plugins/bootstrap-datetimepicker.js" type="text/javascript"></script>
 -->
 <script type="text/javascript">
   
 </script>
 <script src="./assets-pro/js/my.js" type="text/javascript"></script>
<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="../assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
<!--  Google Maps Plugin  -->
<!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/material-kit.js?v=2.0.7" type="text/javascript"></script>
<!-- <script src="assets-pro/js/my.js" type="text/javascript"></script> -->

<script type="text/javascript">

  // function deleteEvent(id){
  //            if(confirm("Are You sure?")){
  //               $.ajax({
  //                  type: 'post',
  //                  url:'./php/delete.php',
  //                  data:{delete_id:id},
  //                  success:function(data){
  //                     $('#delete'+id).hide('slow');
  //                  }
  //               });
  //            }
  //         }

  //    function deleteJob(id){
  //            if(confirm("Are You sure?")){
  //               $.ajax({
  //                  type: 'post',
  //                  url:'./php/deleteJob.php',
  //                  data:{delete_id:id},
  //                  success:function(data){
  //                     $('#delete'+id).hide('slow');
  //                  }
  //               });
  //            }
  //         }

  //          function deleteRegister(id){
  //            if(confirm("Are You sure?")){
  //               $.ajax({
  //                  type: 'post',
  //                  url:'./php/deleteRegister.php',
  //                  data:{delete_id:id},
  //                  success:function(data){
  //                     $('#delete'+id).hide('slow');
  //                  }
  //               });
  //            }
  //         }
</script>