
<title>Alumni Portal</title>
      <meta charset="utf-8"/>
      <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
      <!-- css files -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="assets-pro/css/all.css">
      <link href="../assets/css/material-kit.css?v=2.0.7" rel="stylesheet" />
      <!-- Fonts and Icons  -->
      <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"/>
      <script src="https://kit.fontawesome.com/032efbf5c8.js" crossorigin="anonymous"></script>
      <link rel="icon" href="../assets/img/apple-icon.png" type="image/gif" sizes="16x16">


