<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- CSS only -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

<!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>
<body>
<form onsubmit="return validation()" method="POST" action="#">
	<input type="text" name="" id="user">
	<span id="a"></span>

	<input type="text" name="" id="luser">
	<span id="b"></span>

	<input type="text" name="" id="email">
	<span id="c"></span>

	<input type="text" name="" id="phone">
	<span id="d"></span>

	<input type="text" name="" id="password">
	<span id="e"></span>

	<input type="text" name="" id="cpassword">
	<span id="f"></span>

	<input type="submit" name="submit" value="submit">
	
</form>


<script type="text/javascript">
   // function validation(){
   //    var user = document.getElementById('user').value;
   //    var luser = document.getElementById('luser').value;
   //    var email = document.getElementById('email').value;
   //    var phone = document.getElementById('phone').value;
   //    var password = document.getElementById('password').value;
   //    var cpassword = document.getElementById('cpassword').value;

   //    if(user == ""){
   //       document.getElementById('a').innerHTML="** Please fill the first name**";
   //       return false;
   //    }

   //    if(luser == ""){
   //       document.getElementById('b').innerHTML="** Please fill the last name**";
   //       return false;
   //    }

   //    if(email == ""){
   //       document.getElementById('c').innerHTML="** Please fill the email**";
   //       return false;
   //    }

   //    if(phone == ""){
   //       document.getElementById('d').innerHTML="** Please fill the contact **";
   //       return false;
   //    }

   //    if(password == ""){
   //       document.getElementById('e').innerHTML="** Please fill the password **";
   //       return false;
   //    }

   //    if(cpassword == ""){
   //       document.getElementById('f').innerHTML="** Please fill the password **";
   //       return false;
   //    }
       function validation(){
      var user = document.getElementById('user').value;
      var luser = document.getElementById('luser').value;
      var email = document.getElementById('email').value;
      var phone = document.getElementById('phone').value;
      var password = document.getElementById('password').value;
      var cpassword = document.getElementById('cpassword').value;



      if(user == ""){
         document.getElementById('a').innerHTML="** Please fill the first name**";
         return false;
      }

      if((user.length <=2) || (user.length >20)){
         document.getElementById('a').innerHTML="** Please fill the first name**";
         return false;
      }
      if(!isNaN(user)){
         document.getElementById('a').innerHTML = "** Only characters are allowed**";
         return false;
      }  

      
      if(luser == ""){
         document.getElementById('b').innerHTML="** Please fill the last name**";
         return false;
      }

      if(email == ""){
         document.getElementById('c').innerHTML="** Please fill the email**";
         return false;
      }
      if(email.indexOf('@') <= 0){
         document.getElementById('c').innerHTML="** @ Invalid position**";
         return false;
      }
      if((email.charAt(email.length-4) !='.')&&(email.charAt(email.length-3) !='.')){
         document.getElementById('c').innerHTML="** Invalid email**";
         return false;
      }


      if(phone == ""){
         document.getElementById('d').innerHTML="** Please fill the contact **";
         return false;
      }
      if(isNaN(phone)){
         document.getElementById('d').innerHTML="** User must write digits only not characters **";
         return false;
      }

      if(phone.length != 10){
         document.getElementById('d').innerHTML="** Mobile number must be 10 digits **";
         return false;
      }
   


      if(password == ""){
         document.getElementById('e').innerHTML="** Please fill the password **";
         return false;
      }
       if(cpassword == ""){
         document.getElementById('f').innerHTML="** Please fill the cpassword **";
         return false;
      }


       if((password.length <=5) || (password.length >20)){
         document.getElementById('e').innerHTML="** Please fill the Password**";
         return false;
      }

      if(password !== cpassword){
         document.getElementById('e').innerHTML="** Passwords are not matching**";
         return false;
      }

     
   }

   
   </script>
</body>
</html>